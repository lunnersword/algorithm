###LeetCode Shell


| # | Title | Solution | Difficulty |
|---| ----- | -------- | ---------- |
|4|[Tenth Line](https://leetcode.com/problems/tenth-line/)| [Bash](./TenthLine.sh)|Easy|
|3|[Transpose File](https://leetcode.com/problems/transpose-file/)| [Bash](./TransposeFile.sh)|Medium|
|2|[Valid Phone Numbers](https://leetcode.com/problems/valid-phone-numbers/)| [Bash](./ValidPhoneNumbers.sh)|Easy|
|1|[Word Frequency](https://leetcode.com/problems/word-frequency/)| [Bash](./WordFrequency.sh)|Medium|
